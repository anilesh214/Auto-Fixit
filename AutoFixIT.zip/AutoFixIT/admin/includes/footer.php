   <footer class="footer">
                    2020 © AutoFixIT
                </footer>
